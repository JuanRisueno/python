'''
Crea un programa que:
1. Pida al usuario que introduzca cualquier valor
2. Intente convertirlo a `int`, `float` y `bool`
3. Muestre el tipo de dato original y los resultados de las conversiones
4. Use la función `type()` para verificar los tipos
'''

valor = input ("Introduce un valor: ")
print (valor)
print (type(valor))
valor = 5
print (valor)
print (type(valor))
valor = 5.5
print (valor)
print (type(valor))
valor = True
print (valor)
print (type(valor))